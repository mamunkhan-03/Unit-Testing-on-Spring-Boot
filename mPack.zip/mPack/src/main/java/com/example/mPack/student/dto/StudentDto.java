package com.example.mPack.student.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data

public class StudentDto {

    private Long id;

    private String name;

    private String department;

    private String Address;

    private String mobile ;

    private  String email;

    private Long rank;

}
