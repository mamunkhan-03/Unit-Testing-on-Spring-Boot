package com.example.mPack.internship.dto;

import lombok.Data;

@Data
public class ResponseDto {
    private Long id;
    private String name;
    private String email;
    private String mobile;
}
