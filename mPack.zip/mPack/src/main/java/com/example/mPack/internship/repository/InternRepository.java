package com.example.mPack.internship.repository;

import com.example.mPack.internship.entity.Intern;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InternRepository extends JpaRepository<Intern, Long> {







}
